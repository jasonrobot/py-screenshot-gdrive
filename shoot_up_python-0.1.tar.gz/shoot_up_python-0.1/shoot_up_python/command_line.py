import shoot_up_python

def main():
    shoot_up_python.shoot_up()
